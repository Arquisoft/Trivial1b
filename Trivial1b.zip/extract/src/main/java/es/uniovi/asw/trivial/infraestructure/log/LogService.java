package es.uniovi.asw.trivial.infraestructure.log;

import es.uniovi.asw.trivial.infraestructure.log.impl.Logger;

public interface LogService {
	
	public Logger getLog();

}
