package es.uniovi.asw.trivial.persistence;

public interface PersistenceService {

}
