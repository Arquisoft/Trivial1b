package es.uniovi.asw.trivial.extractor.services.serializer;
/**
 * 
 * @author Adrián
 *
 */
public interface SerializerService {
	/**
	 * 
	 * @return
	 */
	public Serializer getSerializerJson();
}
