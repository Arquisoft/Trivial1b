package es.uniovi.asw.trivial.extractor.services.parser.imp;

import java.util.List;

import es.uniovi.asw.trivial.extractor.services.parser.Parser;
import es.uniovi.asw.trivial.infraestructure.model.Question;
/**
 * 
 * @author Adrián
 *
 */
public class QTIParser implements Parser {

	@Override
	public List<Question> parser(String data) {
		// TODO Auto-generated method stub
		return null;
	}

}
