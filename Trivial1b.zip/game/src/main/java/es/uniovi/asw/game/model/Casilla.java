package es.uniovi.asw.game.model;



public class Casilla {
	
	int pos;

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public Casilla(int pos) {
		super();
		this.pos = pos;
	}
	
	
	
	
}
