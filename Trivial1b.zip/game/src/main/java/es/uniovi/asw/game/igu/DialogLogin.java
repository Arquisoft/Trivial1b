package es.uniovi.asw.game.igu;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import es.uniovi.asw.game.model.Partida;
import es.uniovi.asw.game.model.User;
import es.uniovi.asw.game.model.UserDb;

public class DialogLogin extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4826891126713164125L;
	private final JPanel contentPanel = new JPanel();
	private JPanel pnPrincipal;
	private JPanel pnSpinner;
	private JLabel lbTituloSpinner;
	private JSpinner spJugadores;
	private JButton btnConfirmar;
	private JButton btnRegistrarse;
	private JPanel pnRegistrarse;
	private CardLayout cl = new CardLayout(0, 0);
	private int jugadores = 0;
	private int contador = 0;
	private JPanel pnLogin;
	private JPanel pnCentro;
	private JPanel pnTitulo;
	private JLabel lbTituloLogin;
	private JPanel pnUsuario;
	private JPanel pnPassword;
	private JPasswordField pfPassword;
	private JTextField txUsuario;
	private JButton btConfirmarLogin;
	private Partida partida;
	UserDb usuariodb = new UserDb();
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DialogLogin dialog = new DialogLogin();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
			dialog.setLocationRelativeTo(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DialogLogin() {
		partida = new Partida();
		usuariodb.addUser("aninabg", "seguridad");
		usuariodb.addUser("samolo", "secure");
		setBounds(100, 100, 581, 421);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(cl);
		contentPanel.add(getPnPrincipal(), "pnPrincipal");
		contentPanel.add(getPnLogin(), "pnLogin");
	}

	private JPanel getPnPrincipal() {
		if (pnPrincipal == null) {
			pnPrincipal = new JPanel();
			pnPrincipal.setLayout(new GridLayout(2, 1, 0, 0));
			pnPrincipal.add(getPnSpinner());
			pnPrincipal.add(getPnRegistrarse());
		}
		return pnPrincipal;
	}
	private JPanel getPnSpinner() {
		if (pnSpinner == null) {
			pnSpinner = new JPanel();
			pnSpinner.setLayout(null);
			pnSpinner.add(getLbTituloSpinner());
			pnSpinner.add(getSpJugadores());
			pnSpinner.add(getBtnConfirmar());
		}
		return pnSpinner;
	}
	private JLabel getLbTituloSpinner() {
		if (lbTituloSpinner == null) {
			lbTituloSpinner = new JLabel("Seleccione el n\u00FAmero de jugadores:");
			lbTituloSpinner.setBounds(210, 25, 170, 28);
		}
		return lbTituloSpinner;
	}
	private JSpinner getSpJugadores() {
		if (spJugadores == null) {
			spJugadores = new JSpinner();
			spJugadores.setBounds(274, 71, 43, 28);
			spJugadores.setModel(new SpinnerNumberModel(1, 1, 6, 1));
		}
		return spJugadores;
	}
	private JButton getBtnConfirmar() {
		if (btnConfirmar == null) {
			btnConfirmar = new JButton("Confirmar");
			btnConfirmar.setBounds(239, 117, 108, 31);
			btnConfirmar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					jugadores = (Integer) spJugadores.getValue();
					cl.show(contentPanel, "pnLogin");
					
				}
			});
		}
		return btnConfirmar;
	}
	private JButton getBtnRegistrarse() {
		if (btnRegistrarse == null) {
			btnRegistrarse = new JButton("Registrarse");
			btnRegistrarse.setBounds(249, 46, 117, 32);
		}
		return btnRegistrarse;
	}
	private JPanel getPnRegistrarse() {
		if (pnRegistrarse == null) {
			pnRegistrarse = new JPanel();
			pnRegistrarse.setLayout(null);
			pnRegistrarse.add(getBtnRegistrarse());
		}
		return pnRegistrarse;
	}
	private JPanel getPnLogin() {
		if (pnLogin == null) {
			pnLogin = new JPanel();
			pnLogin.setLayout(new BorderLayout(0, 0));
			pnLogin.add(getPnCentro(), BorderLayout.CENTER);
			pnLogin.add(getPnTitulo(), BorderLayout.NORTH);
		}
		return pnLogin;
	}
	private JPanel getPnCentro() {
		if (pnCentro == null) {
			pnCentro = new JPanel();
			pnCentro.setLayout(null);
			pnCentro.add(getPnPassword());
			pnCentro.add(getPnUsuario());
			pnCentro.add(getBtConfirmarLogin());
		}
		return pnCentro;
	}
	private JPanel getPnTitulo() {
		if (pnTitulo == null) {
			pnTitulo = new JPanel();
			pnTitulo.add(getLbTituloLogin());
		}
		return pnTitulo;
	}
	private JLabel getLbTituloLogin() {
		if (lbTituloLogin == null) {
			lbTituloLogin = new JLabel("Login");
			lbTituloLogin.setFont(new Font("Stencil", Font.PLAIN, 59));
		}
		return lbTituloLogin;
	}
	private JPanel getPnUsuario() {
		if (pnUsuario == null) {
			pnUsuario = new JPanel();
			pnUsuario.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0), 1, true), "Usuario", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
			pnUsuario.setBounds(199, 61, 167, 91);
			pnUsuario.setLayout(null);
			pnUsuario.add(getTxUsuario());
		}
		return pnUsuario;
	}
	private JPanel getPnPassword() {
		if (pnPassword == null) {
			pnPassword = new JPanel();
			pnPassword.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0), 1, true), "Contrase\u00F1a:", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			pnPassword.setBounds(199, 182, 167, 91);
			pnPassword.setLayout(null);
			pnPassword.add(getPfPassword());
		}
		return pnPassword;
	}
	private JPasswordField getPfPassword() {
		if (pfPassword == null) {
			pfPassword = new JPasswordField();
			pfPassword.setBounds(10, 30, 147, 32);
		}
		return pfPassword;
	}
	private JTextField getTxUsuario() {
		if (txUsuario == null) {
			txUsuario = new JTextField();
			txUsuario.setBounds(10, 31, 147, 31);
			txUsuario.setColumns(10);
		}
		return txUsuario;
	}
	private JButton getBtConfirmarLogin() {
		if (btConfirmarLogin == null) {
			btConfirmarLogin = new JButton("Confirmar");
			btConfirmarLogin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					//Obtenemos el usuario y la password de los campos.
					String name = txUsuario.getText();
					String password = String.valueOf(pfPassword.getPassword());
					
					//Si existe en la tabla 
					//TODO modificar por código real bbdd
					if(usuariodb.login(name, password)) {
						partida.getUsuarios().add(usuariodb.lookup(name));
						contador++;
						
					}
					
					if(contador!=jugadores) {
						limpiarLogin();
						cl.show(contentPanel, "pnLogin");
					} else {
						for(User u: partida.getUsuarios())
							System.out.println("Usuario jugando: " + u.toString());
					}
				
				}
			});
			btConfirmarLogin.setBounds(437, 258, 89, 23);
		}
		return btConfirmarLogin;
	}

	protected void limpiarLogin() {
		txUsuario.setText("");
		pfPassword.setText("");
		
	}
}
