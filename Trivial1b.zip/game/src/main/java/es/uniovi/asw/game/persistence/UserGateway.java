package es.uniovi.asw.game.persistence;


import java.net.UnknownHostException;
import java.util.Date;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

public class UserGateway {

	
	//Despues de bajarnos mongo creamos el directorio  $ sudo mkdir -p /data/db
	//http://stackoverflow.com/questions/8029064/new-to-mongodb-can-not-run-command-mongo
	public void connect() {

		MongoClient mongoClient = null;
		try {
			mongoClient = new MongoClient( "localhost", 27017);
		} catch (UnknownHostException e) {
			System.err.println("Cannot connect");
			e.printStackTrace();
		}
		DB db = mongoClient.getDB( "mydb" );
		BasicDBObject document = new BasicDBObject();
		document.put("name", "mkyong");
		document.put("age", 30);
		document.put("createdDate", new Date());
		DBCollection table = db.createCollection("user", document);
		System.out.println("Collection created successfully");
		
	}
	                                    
}
