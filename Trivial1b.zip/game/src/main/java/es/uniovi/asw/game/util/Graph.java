package es.uniovi.asw.game.util;

import java.text.DecimalFormat;

public class Graph<T> {

	private T[] nodes;
	private boolean[][] edges; // Matriz de adyacencia.
	private double[][] weights; // Matriz de pesos
	private int numNodes; // N�mero de nodos que hay en un momento dado en el
	private double[][] A;
	private T[] pDijkstra;
	private double[] dDijkstra;
	private int[][] pFloyd;
			
	/**
	 * Constructor de la clase Graph.
	 * 
	 * @param tamMaximo
	 *            indica el n�mero m�ximo de nodos que podr� tener el grafo.
	 */
	public Graph(int tamMaximo) {

		nodes = (T[])new Object[tamMaximo];
		edges = new boolean[tamMaximo][tamMaximo];
		weights = new double[tamMaximo][tamMaximo];
		numNodes = 0;		

	}

	/**
	 * M�todo que a�ade un nodo. Si el grafo est� lleno o existe ese nodo no se
	 * a�ade. En cualquier otro caso, se a�ade el nodo al vector y se modifican
	 * las matrices de adyacencia y de pesos.
	 * 
	 * @param node
	 *            el nodo que se quiere a�adir
	 * @return int -1 si no se ha podido a�adir y 0 si se ha podido a�adir
	 */
	public int addNode(T node) {

		if (numNodes == nodes.length || existNode(node)) {

			return -1;

		}

		else {

			nodes[numNodes] = (T) node;

			// Recorremos la matriz hasta el numero de nodos.
			for (int i = 0; i < numNodes; i++) {

				edges[i][numNodes] = false;
				edges[numNodes][i] = false;
				weights[i][numNodes] = 0; // Cuando no hay una arista -> peso
												// 0. No se admiten pesos
												// negativos.
				weights[numNodes][i] = 0;

			}

			numNodes++;

			return 0;
		}

	}

	/**
	 * Comprueba si existe el nodo.
	 * 
	 * @param node
	 *            el nodo del que se quiere saber su existencia
	 * @return boolean true si existe, false si no existe.
	 */
	public boolean existNode(T node) {

		return getNode(node) != -1;

	}

	public int addEdge(T source, T target, double weight) {

		if (!existNode(source) || !existNode(target) || weight < 0) {

			return -1;

		}

		else {

			// Obtenemos las posiciones de ambos nodos.
			int posSource = getNode(source);
			int posTarget = getNode(target);

			// Modificamos las matrices de adyacencia y de pesos para crear la
			// arista.
			edges[posSource][posTarget] = true;
			weights[posSource][posTarget] = weight;

			return 0;
		}

	}

	/**
	 * Obtiene la posici�n del nodo.
	 * 
	 * @param node
	 *            el nodo del que se quiere saber su posici�n
	 * @return int -1 si no se encuentra, la posici�n si se encuentra en el
	 *         vector de nodos
	 */
	private int getNode(T node) {

		for (int i = 0; i < numNodes; i++) {

			if (node.equals(nodes[i])) {

				return i;

			}

		}

		return -1;

	}

	/**
	 * Elimina una arista entre dos nodos. Si no existe alguno de los dos nodos
	 * o no existe la arista no se elimina. En cualquier otro caso se modifican
	 * las matrices de adyacencia y de pesos.
	 * 
	 * @param source
	 *            el nodo de origen
	 * @param target
	 *            el nodo de destino
	 * @return int -1 si no se puede eliminar y 0 si se ha eliminado
	 *         correctamente.
	 */
	public int removeEdge(T source, T target) {

		// Obtenemos las posiciones de ambos nodos.
		int posSource = getNode(source);
		int posTarget = getNode(target);

		if (!existNode(source) || !existNode(target)
				|| !edges[posSource][posTarget]) {

			return -1;

		} else {

			// Modificamos las matrices de adyacencia y de pesos para eliminar
			// la arista.
			edges[posSource][posTarget] = false;
			weights[posSource][posTarget] = 0;

			return 0;

		}

	}

	/**
	 * Elimina un nodo. Si no existe no se elimina. Si existe se modifican las
	 * matrices.
	 * 
	 * @param node
	 *            el nodo a eliminar
	 * @return int -1 si no se elimina y 0 si se ha eliminado correctamente.
	 */
	public int removeNode(T node) {
		if (!existNode(node)) {

			return -1;
		} else {

			int pos = getNode(node);
			numNodes--;

			if (pos != numNodes) {

				for (int i = 0; i < numNodes; i++) {

					edges[pos][i] = edges[numNodes][i];
					edges[i][pos] = edges[i][numNodes];
					weights[pos][i] = weights[numNodes][i];
					weights[i][pos] = weights[i][numNodes];
					edges[pos][pos] = edges[numNodes][numNodes];
					weights[pos][pos] = weights[numNodes][numNodes];
				}

				nodes[pos] = nodes[numNodes];

			}

			for (int i = 0; i < numNodes; i++) {

				edges[numNodes][i] = false;
				edges[i][numNodes] = false;
				weights[numNodes][i] = 0;
				weights[i][numNodes] = 0;
			}

			nodes[numNodes] = null;
			return 0;
		}

	}

	/**
	 * Devuelve el peso de una arista.
	 * 
	 * @param source
	 *            el nodo de origen
	 * @param target
	 *            el nodo de destino
	 * @return double el peso de dicha arista si existe o -1 si no existe.
	 */
	public double getEdge(T source, T target) {

		int posSource = getNode(source);
		int posTarget = getNode(target);

		if (!existNode(source) || !existNode(target)
				|| !edges[posSource][posTarget]) {

			return -1;

		}

		else {

			return weights[posSource][posTarget];

		}

	}

	/**
	 * Recorre todos los nodos desde un nodo que se le pasa como par�metro.
	 * 
	 * @param node
	 *            el nodo origen.
	 * @return int -1 si no recorre todos los nodos, 0 si los recorre.
	 * */
	public int recorridoProfundidad(T node) {
		boolean[] visitados = new boolean[numNodes];
		int indice = getNode(node);

		if (!existNode(node)) {

			return -1;
		}

		else {

			recProf(indice, visitados);
			for (int i = 0; i < numNodes; i++) {

				if (!visitados[i]) {

					return -1;
				}

			}
			return 0;

		}

	}

	/**
	 * Imprime por pantalla el nodo que se le pasa.
	 * 
	 * @param nodo
	 *            el nodo a tratar
	 * @return int -1 si no se puede tratar, 0 si se puede tratar.
	 */
	private int tratarNodo(int node) {

		if (!existNode(nodes[node])) {
			return -1;
		}

		else {

			System.out.print(nodes[node].toString() + "\t");
			return 0;

		}

	}

	/**
	 * M�todo recursivo que recorre los hijos del nodo que est� en la posici�n
	 * que se le pasa como par�metro.
	 * 
	 * @param nodo
	 *            la posici�n del nodo.
	 * @param v
	 *            vector en el que se indica si los nodos est�n visitados o no.
	 *            True si est�n visitados, false si no.
	 */
	private void recProf(int nodo, boolean[] v) {

		tratarNodo(nodo);
		v[nodo] = true;

		for (int i = 0; i < numNodes; i++) {

			if (edges[nodo][i] && !v[i]) {

				recProf(i, v);

			}

		}

	}

	/**
	 * Aplica el algoritmo de dijkstra desde el nodo que se le pasa como
	 * par�metro.
	 * 
	 * @param nodo
	 *            el nodo de origen.
	 * @return double[] el vector de distancias resultante de aplicar el
	 *         algoritmo.
	 */
	public double[] dijkstra(T nodo) {
		int pos = getNode(nodo);
		dDijkstra = new double[numNodes];
		pDijkstra = (T[])new Object[numNodes];
		boolean[] v = new boolean[numNodes];
		
		for (int i = 0; i < numNodes; i++) {

			if (pos==i) {

				pDijkstra[i] = nodo;
				dDijkstra[i] = 0;

			}

			else if ( weights[pos][i] != 0) {

				dDijkstra[i] = weights[pos][i];
				pDijkstra[i] = nodo;

			} else {

				dDijkstra[i] = Double.MAX_VALUE;
				pDijkstra[i] = null;
			}

		}

		int indice = minCoste(dDijkstra,v);
		
		while (indice!=-1) {
			
			v[indice] = true;
			
			for (int i = 0; i < numNodes; i++) {

				if (dDijkstra[indice] + weights[indice][i] < dDijkstra[i] && dDijkstra[indice]!=Double.MAX_VALUE && weights[indice][i]!=0 ) {
					dDijkstra[i] = dDijkstra[indice] + weights[indice][i];
					pDijkstra[i] = nodes[indice];
				}

			}
			indice = minCoste(dDijkstra,v);
		}
		
		return dDijkstra;	
	}

	
	public double[][] getA() {
		return A;
	}

	public void setA(double[][] a) {
		A = a;
	}

	public T[] getpDijkstra() {
		return pDijkstra;
	}

	public void setpDijkstra(T[] pDijkstra) {
		this.pDijkstra = pDijkstra;
	}

	public double[] getdDijkstra() {
		return dDijkstra;
	}

	public void setdDijkstra(double[] dDijkstra) {
		this.dDijkstra = dDijkstra;
	}

	public int[][] getpFloyd() {
		return pFloyd;
	}

	public void setpFloyd(int[][] pFloyd) {
		this.pFloyd = pFloyd;
	}

	/**
	 * Devuelve el coste minimo.
	 * @param d el vector D de Dijkstra
	 * @param v el vector de nodos visitados.
	 * @return int la posicion en que se encuentra el coste minimo.
	 */
	private int minCoste(double[] d, boolean[] v) {
		
		int numVisitados = 0;
		for (int i = 0; i < numNodes; i++) {

			if (v[i]) {

				numVisitados++;
			}

		}

		if (numVisitados != numNodes) {
			double max = Double.MAX_VALUE;
			int menor = 0;
			for (int i = 0; i < numNodes;i++) {
					if(!v[i] && d[i]<=max) {
						max = d[i];
						menor = i;
						
					
				}
				
			}
			return menor;
		}
		else{
			
			return -1;
		}
	}
	
	
	
	/**
	 * Aplica el algoritmo de Floyd al grafo actual.
	 * @return int[][] la matriz P de floyd.
	 */
	public int[][] floyd() {
		pFloyd = new int[numNodes][numNodes];
		A = new double[numNodes][numNodes];
		double aux = 0;
		
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				pFloyd[i][j] = -1;
				if (weights[i][j] != 0) {
					A[i][j] = weights[i][j];
				} else { //Cuando no haya camino directo, es decir, cuando weights[i][j] ==0
					//Coloco infinito en A[i][j]
					A[i][j] = Double.MAX_VALUE;
					
				}
				
			}
			A[i][i] = 0; //Pongo a 0 la diagonal principal.
			
		}
		
	

		for (int k = 0; k < numNodes; k++) {
			for (int i = 0; i < numNodes; i++) {
				for (int j = 0; j < numNodes; j++) {
					if (A[i][k] != Double.MAX_VALUE
							&& A[k][j] != Double.MAX_VALUE) {
						aux = A[i][k] + A[k][j];
						if (aux < A[i][j]) {
							A[i][j] = aux;
							pFloyd[i][j] = k;
						}
					}
				}
			}
		}

		return pFloyd;

	}

	/**
	 * 
	 * @param source
	 * @param target
	 * @return double coste acumulando el paso por las aristas desde el nodo
	 *         origen al nodo destino.
	 */
	public double path(T source, T target) {
		if(!existNode(source) || !existNode(target))
			return -1;
		int possour = getNode(source);
		int postar = getNode(target);
		
		if (possour==postar) {
			tratarNodo(possour);
			return 0;
		} 
		
		floyd();
		
		if (A[possour][postar]==Double.MAX_VALUE) 
			return -1;

		tratarNodo(possour);
		double costeTotal = recpath(possour, postar, pFloyd);
		tratarNodo(postar);
		return costeTotal;
		
	}
	
	
	private double recpath(int i,int j,int[][] pfloyd) {
		
		int k = pfloyd[i][j];
		double coste = 0;
		 
		if(k>=0) {
			
			coste += recpath(i,k, pfloyd);
			tratarNodo(k);
			coste += recpath(k,j,pfloyd);
			
		}
		else if(edges[i][j])
			coste+=weights[i][j];
		
	
		return coste;
		
	}
	
	
	public T[] getNodes() {
		return nodes;
	}

	public void setNodes(T[] nodes) {
		this.nodes = nodes;
	}

	public boolean[][] getEdges() {
		return edges;
	}

	public void setEdges(boolean[][] edges) {
		this.edges = edges;
	}

	public double[][] getWeights() {
		return weights;
	}

	public void setWeights(double[][] weights) {
		this.weights = weights;
	}

	public int getNumNodes() {
		return numNodes;
	}

	public void setNumNodes(int numElements) {
		this.numNodes = numElements;
	}

	public String toStringAssert() {
		String cadena = "";
		T[] nodos = getNodes();
		boolean[][] aristas = getEdges();
		double[][] pesos = getWeights();
		int numNodos = getNumNodes();
		
		cadena += "VECTOR NODOS\n{";
		for (int i = 0; i < nodos.length; i++) {
			if (nodos[i]==null || i>=numNodos)
				cadena+="null";
			else
				cadena += nodos[i].toString();
			if (i<nodos.length-1) 
				cadena+= ", ";
		}
		cadena+="}";
		cadena += "\n\nMATRIZ ARISTAS\n";
		cadena+="{"; 
		for	(int i=0; i<aristas.length; i++) {
			cadena+="{";
			for (int j=0; j<aristas.length; j++) { 
				if (i<numNodes && j<numNodes)
					cadena += aristas[i][j]?"T":"F";
				else
					cadena+="F";
				if (j<aristas.length-1)
					cadena+=", "; 
			} 
			cadena += "}";
			if (i<aristas.length-1)
				cadena+=",\n ";
		} 
		cadena+="}";

		
		cadena += "\n\nMATRIZ PESOS\n";
		DecimalFormat df = new DecimalFormat(" #.## ");
		cadena+="{"; 
		for	(int i=0; i<pesos.length; i++) {
			cadena+="{";
			for (int j=0; j<nodes.length; j++) { 
				if (i<numNodes&&j<numNodes)
					cadena += 	df.format(pesos[i][j]);
				else
					cadena+=df.format(0);
				if (j<pesos.length-1)
					cadena+=","; 
			} 
			cadena += "}";
			if (i<pesos.length-1)
				cadena+=",\n ";
		} 
		cadena+="}\n";
		return cadena;
}
}
