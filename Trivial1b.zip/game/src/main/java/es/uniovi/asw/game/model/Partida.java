package es.uniovi.asw.game.model;

import java.util.ArrayList;
import java.util.List;

import es.uniovi.asw.game.util.Graph;

public class Partida {

	private Graph<Casilla> tablero;
	private final static int POSINITX = 4;
	private final static int POSINITY = 4;
	private final static int MAX = 6;
	private int dado;
	private Casilla[] casillas;
	private final static int TAMANIOTABLERO = 81;
	private List<User> usuarios;
	
	public Partida() {
		usuarios = new ArrayList<User>();
		tablero = new Graph<Casilla>(TAMANIOTABLERO);
		inicializaTablero();
		

		
	}
	
	
	public List<User> getUsuarios() {
		return usuarios;
	}


	public void setUsuarios(List<User> usuarios) {
		this.usuarios = usuarios;
	}


	private void inicializaTablero() {
		tablero.setEdges(new boolean[][]{{false, false, false, false, false, false, false, false, false},
										{false, true, true, true, false, true, true, true, false},
										{false, true, true, true, false, true, true, true, false},
										{false, true, true, true, false, true, true, true, false},
										{false, false, false, false, false, false, false, false, false},
										{false, true, true, true, false, true, true, true, false},
										{false, true, true, true, false, true, true, true, false},
										{false, true, true, true, false, true, true, true, false},
										{false, false, false, false, false, false, false, false, false}});
		
	}


	public int lanzarDado() {
		int dado = (int)(Math.random() * 6) + 1;
		return dado;
	}

	private void mover() {
		for(int i=0; i<dado; i++) {
			
		}
	}
}
