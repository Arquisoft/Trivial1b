# Trivial1b
[![Build Status](https://travis-ci.org/Arquisoft/Trivial1b.svg?branch=master)](https://travis-ci.org/Arquisoft/Trivial1b)
## Equipo formado por: 
<table>
  <tr>
    <th>Nombre</th>
    <th>Apellidos</th>
    <th>UO</th>
  </tr>
  <tr>
    <td>Adrián</td>
    <td>García Bueno</td>
    <td>UO232346</td>
  </tr>
  <tr>
    <td>Ana Isabel</td>
    <td>Blanco González</td>
    <td>UO227799</td>
  </tr>
  <tr>
    <td>Benigno</td>
    <td>Diez Gutiérrez</td>
    <td>UO227982</td>
  </tr>
  <tr>
    <td>Borja</td>
    <td>Caveda Cano</td>
    <td>UO227648</td>
  </tr>
  <tr>
    <td>Cristian</td>
    <td>Pérez González</td>
    <td>UO191154</td>
  </tr>
  <tr>
    <td>María</td>
    <td>Hernández Martínez</td>
    <td>UO229803</td>
  </tr>
  <tr>
    <td>María José</td>
    <td>Sanchez Doria</td>
    <td>UO232334</td>
  </tr>
  <tr>
    <td>Samuel</td>
    <td>Fernández Cabello</td>
    <td>UO224927</td>
  </tr>
  <tr>
    <td>Sergio</td>
    <td>Berjano Salinas</td>
    <td>UO212948</td>
  </tr>
</table>

<a href="http://arquisoft.github.io/Trivial1b/">URL de la página del proyecto</a>
